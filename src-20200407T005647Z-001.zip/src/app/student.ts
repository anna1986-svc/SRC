export class Student {

    rollNo:number;
    name:String;
    course:String;
    fee:number;

    constructor(rollNo:number = 0, name:String = "", course:String = "", fee:number = 0){
            this.rollNo = rollNo;
            this.name = name;
            this.course = course;
            this.fee = fee;
    }

}

import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-ang-validations',
  templateUrl: './ang-validations.component.html',
  styleUrls: ['./ang-validations.component.css']
})
export class AngValidationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  newStudent:Student = new Student();

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AngValidationsComponent } from './ang-validations.component';

describe('AngValidationsComponent', () => {
  let component: AngValidationsComponent;
  let fixture: ComponentFixture<AngValidationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AngValidationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AngValidationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

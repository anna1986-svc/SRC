import { Component, OnInit } from '@angular/core';
import { RestApiCallsSrvService } from '../rest-api-calls-srv.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-http-demo',
  templateUrl: './http-demo.component.html',
  styleUrls: ['./http-demo.component.css']
})
export class HttpDemoComponent implements OnInit {

  constructor(private restApiSrv:RestApiCallsSrvService) { }

  ngOnInit(): void {
       var storageAreaInfo = localStorage.getItem("employeesData");
      if(storageAreaInfo != null){
            this.allEmployees = JSON.parse(storageAreaInfo);
      }
  }

  getAllEmployees(){
  	   this.restApiSrv.invokeGetAllRestApi()
            .subscribe(data => {
               this.allEmployees = data;
               localStorage.setItem("employeesData", JSON.stringify(data));
              } );
  }

  allEmployees:Employee[] = [];

  isReadOnly:boolean = true;
  isUpdate:boolean = false;
  isInsert:boolean = false;
  selectedEmp:Employee = new Employee();

  selectEmp(obj){
       this.selectedEmp = obj;
  }

  deleteEmployee(){
      this.restApiSrv.invokeDeleteRestApi(this.selectedEmp.emplId)
              .subscribe(data=>{

              })
      this.selectedEmp = new Employee();
  }

  updateEmployee(){
       this.isReadOnly = false;
       this.isUpdate = true;
  }

  sendEmpInfo(){
      if(this.isInsert){
          this.restApiSrv.invokeInsertRestApi(this.selectedEmp)
                .subscribe(data => {
                    
                });
      }else if(this.isUpdate){
         this.restApiSrv.invokeUpdateRestApi(this.selectedEmp)
                .subscribe(data => {
                     
                });
        }     

      this.isInsert = false;  
      this.isUpdate = false;
      this.selectedEmp = new Employee();
      this.isReadOnly = true;
  }

  insertNewEmployee(){
        this.isReadOnly = false;
        this.selectedEmp = new Employee();
        this.isInsert = true;
  }

}

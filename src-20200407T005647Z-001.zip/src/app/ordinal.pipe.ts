import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ordinal'
})
export class OrdinalPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    	
  		var input = value;
  		var output;

  		var lastDigitOfNumber = input % 10;
  		if(lastDigitOfNumber == 1){
  		     output = input +" st";
  		}else if(lastDigitOfNumber == 2){
  		     output = input +" nd";
  		}else if(lastDigitOfNumber == 3){
  		     output = input +" rd";
  		}else{
  			output = input +" th";
  		}
  	 return output;	
  }

}



import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  receiveTester(obj){
      this.selectedTester = obj;
  }

  selectedTester:Student = new Student();

  testers:Student[] = [
  						 {
  						   rollNo : 501,
  						   name : "sahithya",
  						   course : "testNg",
  						   fee : 4000
  						 },
  						 {
  						   rollNo : 504,
  						   name : "rajitha",
  						   course : "junit",
  						   fee : 6000
  						 },
  						 {
  						   rollNo : 503,
  						   name : "sahithi",
  						   course : "jasmine",
  						   fee : 7000
  						 },
  						 {
  						   rollNo : 507,
  						   name : "anil",
  						   course : "jMockit",
  						   fee : 8000
  						 },
  						 {
  						   rollNo : 509,
  						   name : "nandu",
  						   course : "mockito",
  						   fee : 7000
  						 }
  					];

}

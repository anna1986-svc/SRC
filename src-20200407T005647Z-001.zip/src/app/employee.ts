export class Employee {

   emplId:number;
   emplName:string;
   salary:number;
   bonus:number;
   deptId:number;
   mgrId:number;

   constructor(emplId:number=0, emplName:string='', salary:number=0, bonus:number=0, deptId:number=0, mgrId:number=0 ){
         this.emplId = emplId;
         this.emplName = emplName;
         this.salary = salary;
         this.bonus = bonus;
         this.deptId = deptId;
         this.mgrId = mgrId;
   }

}

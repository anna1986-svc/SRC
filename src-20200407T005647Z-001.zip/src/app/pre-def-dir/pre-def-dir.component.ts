import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { ActivatedRoute, Router }  from '@angular/router';
import { DataCarrierService } from '../data-carrier.service';

@Component({
  selector: 'app-pre-def-dir',
  templateUrl: './pre-def-dir.component.html',
  styleUrls: ['./pre-def-dir.component.css']
})
export class PreDefDirComponent implements OnInit {

  constructor(private actRouteVar:ActivatedRoute, 
              private routerVar:Router,
              private dataCarrierSrv:DataCarrierService) { }

  ngOnInit(): void {     
     this.receivedCourse = this.actRouteVar.snapshot.paramMap.get("info");
  }

  navigateDb(inputUrl){
      this.dataCarrierSrv.setStInSrv(this.selectedStudent); 
      this.routerVar.navigate([inputUrl]);
  }

  receivedCourse:string = '';

  courses:string[] = ["html", "css", "js", "jQuery", "TypeScript", "Angular"];

  selectedCourse:string = "";

  selectedStudent:Student = {
  							  rollNo : 0,
  							  name : '',
  							  course : '',
  							  fee : 0		
  							};

  selectedStudentName : string = "";

  students:Student[] = [
  						{
  						   rollNo : 101,
  						   name : "harsha",
  						   course : "java",
  						   fee : 9000
  						},
  						{
  						   rollNo : 102,
  						   name : "sneha",
  						   course : "angular",
  						   fee : 5000
  						},	{
  						   rollNo : 110,
  						   name : "sushma",
  						   course : "sql",
  						   fee : 3000
  						},{
  						   rollNo : 105,
  						   name : "babu",
  						   course : "spring",
  						   fee : 7000
  						},{
  						   rollNo : 106,
  						   name : "anil",
  						   course : "angular",
  						   fee : 6000
  						},
  					];

}

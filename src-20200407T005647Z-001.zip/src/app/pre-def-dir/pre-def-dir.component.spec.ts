import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreDefDirComponent } from './pre-def-dir.component';

describe('PreDefDirComponent', () => {
  let component: PreDefDirComponent;
  let fixture: ComponentFixture<PreDefDirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreDefDirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreDefDirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

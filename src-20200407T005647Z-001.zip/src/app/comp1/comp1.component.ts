import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  receiveData(obj){
      this.selectedDevInfo = obj;
  }

  selectedDevInfo :Student = new Student();

  developers:Student[] = [
  						    {
  						       rollNo : 101,
  						       name : "harsha",
  						       course : "java",
  						       fee : 9000
  						    },
  						    {
  						      rollNo : 110,
  						      name : "harika",
  						      course : "html",
  						      fee : 8000
  						    },
  						    {
  						      rollNo : 108,
  						      name : "sneha",
  						      course : "angular",
  						      fee : 8000
  						    },
  						    {
  						       rollNo : 105,
  						       name : "rakesh",
  						       course : "spring",
  						       fee : 8900
  						    }
  						];

}

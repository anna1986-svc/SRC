import { Injectable } from '@angular/core';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class DataCarrierService {

  constructor() { }

  private stInSrv:Student;

  getStInSrv():Student{
      return this.stInSrv;
  }

  setStInSrv(st:Student){
      this.stInSrv = st;
  }

}

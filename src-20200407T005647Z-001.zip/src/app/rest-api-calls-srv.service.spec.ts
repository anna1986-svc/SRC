import { TestBed } from '@angular/core/testing';

import { RestApiCallsSrvService } from './rest-api-calls-srv.service';

describe('RestApiCallsSrvService', () => {
  let service: RestApiCallsSrvService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RestApiCallsSrvService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

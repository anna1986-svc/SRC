import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-comm',
  templateUrl: './comm.component.html',
  styleUrls: ['./comm.component.css']
})
export class CommComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Input()
  students:Student[] = [];

  @Output()
  resp = new EventEmitter();

  passData(rowData){
      this.resp.emit(rowData);
  }

}

import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-pipes-demo',
  templateUrl: './pipes-demo.component.html',
  styleUrls: ['./pipes-demo.component.css']
})
export class PipesDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  amount:number = 5000;

  estDate:Date;

  salary : number = 9797978;

  course:string = "java Script";

  st:Student = new Student(101, "harsha", "java", 9000);

  courses:String[] = ["html", "css", "js", 
  						"jQuery", "ajax", "typeScript", "Angular", "Bootstrap", "GitHub"];

  limit:number = 0;

  dateVal:number = 0;

}

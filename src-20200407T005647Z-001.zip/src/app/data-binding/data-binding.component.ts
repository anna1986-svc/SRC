import { Component, OnInit } from '@angular/core';
import { Router }  from '@angular/router';
import { DataCarrierService } from '../data-carrier.service';
import { Student } from '../student';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {

  constructor(private routerVar:Router,
              private dataCarrSrv:DataCarrierService  ) { }

  ngOnInit(): void {
       this.receivedStudentInfo = this.dataCarrSrv.getStInSrv();
  }

  receivedStudentInfo:Student=new Student();

  course:String = "JAVA";

  navigateScreen(inputUrl){
  		this.routerVar.navigate([inputUrl, {info: this.course}]);
  }

}

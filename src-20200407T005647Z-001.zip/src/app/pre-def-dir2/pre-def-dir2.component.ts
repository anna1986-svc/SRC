import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-def-dir2',
  templateUrl: './pre-def-dir2.component.html',
  styleUrls: ['./pre-def-dir2.component.css']
})
export class PreDefDir2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  courses:String[] = ["html", "css", "javaScript", "java"];

  selectedCourse:String = "";

  userName:String = "";

  cssCarrier:String = "";

  validate(){
    
      var noOfCharacters = this.userName.length;
      if(noOfCharacters <= 5){
      		 this.cssCarrier = "weakCls";
      }else if(noOfCharacters <= 10){
      		 this.cssCarrier = "moderateCls";
      }else{
      		 this.cssCarrier = "strongCls";
      }
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class RestApiCallsSrvService {

  constructor(private httpVar:HttpClient) { }

  invokeGetAllRestApi():Observable<any>{
       var restApi = "http://localhost:8080/restApp/emp/getAll";
       return this.httpVar.get(restApi);
  }

  invokeDeleteRestApi(selectedEmplId):Observable<any>{
  	   var restApi = "http://localhost:8080/restApp/emp/delete?emplId="+selectedEmplId;
  	   return this.httpVar.delete(restApi);
  }

  invokeUpdateRestApi(selectedEmp):Observable<any>{
       var restApi ="http://localhost:8080/restApp/emp/update";
        var httpOptions = {
	                            headers: new HttpHeaders({
	                              'Content-Type':  'application/json',
	                              'Accept':'*/*'
	                            })
	                          };
       return this.httpVar.put(restApi, selectedEmp, httpOptions);
  }

  invokeInsertRestApi(selectedEmp):Observable<any>{
       var restApi = "http://localhost:8080/restApp/emp/insert";
        var httpOptions = {
	                            headers: new HttpHeaders({
	                              'Content-Type':  'application/json',
	                              'Accept':'*/*'
	                            })
	                          };
	   return this.httpVar.post(restApi, selectedEmp, httpOptions);
  }

}

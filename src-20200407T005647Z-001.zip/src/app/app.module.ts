import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Route } from "@angular/router";
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { PreDefDirComponent } from './pre-def-dir/pre-def-dir.component';
import { PreDefDir2Component } from './pre-def-dir2/pre-def-dir2.component';
import { PipesDemoComponent } from './pipes-demo/pipes-demo.component';
import { OrdinalPipe } from './ordinal.pipe';
import { DataCarrierService } from './data-carrier.service';
import { Comp1Component } from './comp1/comp1.component';
import { Comp2Component } from './comp2/comp2.component';
import { CommComponent } from './comm/comm.component';
import { AngValidationsComponent } from './ang-validations/ang-validations.component';
import { HttpDemoComponent } from './http-demo/http-demo.component';
import { RestApiCallsSrvService } from './rest-api-calls-srv.service';

const routingConfiguration:Route[] = [
                                      {path:'db', component:DataBindingComponent},
                                      {path:'preDefDir', component:PreDefDirComponent},
                                      {path:'pipes', component:PipesDemoComponent},
                                      {path:'comp1', component:Comp1Component},
                                      {path:'comp2', component:Comp2Component},
                                      {path:'valid', component:AngValidationsComponent},
                                      {path:'httpDemo', component:HttpDemoComponent}
                                    ];

@NgModule({
  declarations: [
    AppComponent,
    DataBindingComponent,
    PreDefDirComponent,
    PreDefDir2Component,
    PipesDemoComponent,
    OrdinalPipe,
    Comp1Component,
    Comp2Component,
    CommComponent,
    AngValidationsComponent,
    HttpDemoComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule, RouterModule.forRoot(routingConfiguration)
  ],
  providers: [DataCarrierService, RestApiCallsSrvService],
  bootstrap: [AppComponent]
})
export class AppModule { }

